<?php 
print_r($_FILES);
print_r($_POST);
